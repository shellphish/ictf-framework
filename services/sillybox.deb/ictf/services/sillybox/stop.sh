#!/bin/bash
pkill -u sillybox
sleep 1
pkill -KILL -u sillybox
        
