#!/bin/bash
pkill -u driller
sleep 1
pkill -KILL -u driller
