#!/bin/bash
pkill -u tattletale
sleep 1
pkill -KILL -u tattletale
